from . import res_config_settings
from . import web_editor_assets
from . import ir_attachment
from . import ir_asset
